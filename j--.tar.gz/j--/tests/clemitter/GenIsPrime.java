import jminusminus.CLEmitter;
import static jminusminus.CLConstants.*;
import java.util.ArrayList;

public class GenIsPrime {
    public static void main(String[] args) {
        CLEmitter e = new CLEmitter(true);
ArrayList<String> accessFlags = new ArrayList<String>();

        // Add GenIsPrime class
        accessFlags.add("public");
        e.addClass(accessFlags, "IsPrime", "java/lang/Object", null, true);

      

        // Add isPrime() method to IsPrime
        accessFlags.clear();
        accessFlags.add("private");
        accessFlags.add("static");
        e.addMethod(accessFlags, "isPrime", "(I)Z", 
        null, true);

        
        // Load n on the stack
        e.addNoArgInstruction(ILOAD_0);
        // push the constant 2 on the stack
        e.addNoArgInstruction(ICONST_2);
        // Branch to "Label1" if n >= 2
        e.addBranchInstruction(IF_ICMPGE, "Label1");

        // Base case: load 0 for false on stack and return to caller
        e.addNoArgInstruction(ICONST_0);
        e.addNoArgInstruction(IRETURN);

        // Emit label "Label1"
        e.addLabel("Label1");
        //store i =2 in offset 1 // load then store
        e.addNoArgInstruction(ICONST_2);
        e.addNoArgInstruction(ISTORE_1);
        e.addLabel("Label4");
        // Load i on the stack
        e.addNoArgInstruction(ILOAD_1);
        // Load n on the stack
        e.addNoArgInstruction(ILOAD_0);
        // Load i on the stack
        e.addNoArgInstruction(ILOAD_1);
        // Divide n by i
        e.addNoArgInstruction(IDIV);
        
        //if i > (n/i) goto label 2
        e.addBranchInstruction(IF_ICMPGT, "Label2");
        // Load n on the stack
        e.addNoArgInstruction(ILOAD_0);
        // Load i on the stack
        e.addNoArgInstruction(ILOAD_1);
        // n mod i 
        e.addNoArgInstruction(IREM);
        // push 0 onto stack
        e.addNoArgInstruction(ICONST_0);
        // if n%i != 0 go to label3
        e.addBranchInstruction(IF_ICMPNE, "Label3");
        // load 0 for false on stack and return to caller
        e.addNoArgInstruction(ICONST_0);
        e.addNoArgInstruction(IRETURN);
        e.addLabel("Label3");
        // increment i by 1
        e.addIINCInstruction(1, 1);
        // go to 4
        e.addBranchInstruction(GOTO, "Label4");
        e.addLabel("Label2");
        // load 1 for true on stack and return to caller
        e.addNoArgInstruction(ICONST_1);
        e.addNoArgInstruction(IRETURN);

        // Add main() method to IsPrime
        accessFlags.clear();
        accessFlags.add("public");
        accessFlags.add("static");
        e.addMethod(accessFlags, "main", "([Ljava/lang/String;)V", null, true);
    
        // Get command-line argument n, convert it into an integer, and
        // store it away
        // load args array
        e.addNoArgInstruction(ALOAD_0);
        // push constant 0 
        e.addNoArgInstruction(ICONST_0);
        // use aaload to load value from args array at index 0
        e.addNoArgInstruction(AALOAD);
        e.addMemberAccessInstruction(INVOKESTATIC, "java/lang/Integer",
                                                   "parseInt", 
                                                   "(Ljava/lang/String;)I");
        //store n in offset 1                                           
        e.addNoArgInstruction(ISTORE_1);
        //load n onto stack
        e.addNoArgInstruction(ILOAD_1);
        // call isPrime on n
        e.addMemberAccessInstruction(INVOKESTATIC, "IsPrime",
                                                   "isPrime", 
                                                   "(I)Z");
       //add branch where it is true go to label 5
        e.addBranchInstruction(IFNE, "Label5");
        // this means its false
        //get system out on the stack
        e.addMemberAccessInstruction(GETSTATIC, "java/lang/System", "out",
                                                "Ljava/io/PrintStream;");
         // Create an intance sb of StringBuffer on the stack and duplicate it
        e.addReferenceInstruction(NEW, "java/lang/StringBuffer");
        e.addNoArgInstruction(DUP);
        // Invoke the constructor StringBuffer()
        e.addMemberAccessInstruction(INVOKESPECIAL, "java/lang/StringBuffer",
                                                    "<init>", 
                                                    "()V");
        // Load n on the stack and append it to sb
        e.addNoArgInstruction(ILOAD_1);
        e.addMemberAccessInstruction(INVOKEVIRTUAL, "java/lang/StringBuffer",
                                                    "append", 
                                                "(I)Ljava/lang/StringBuffer;");
        // Load the constant " is not a prime number" on the stack
        // and call instance
        // method StringBuffer.append() to append it to sb
        e.addLDCInstruction(" is not a prime number");
        e.addMemberAccessInstruction(INVOKEVIRTUAL, "java/lang/StringBuffer",
                                                    "append", 
                                "(Ljava/lang/String;)Ljava/lang/StringBuffer;");
        // Invoke instance method sb.toString() to turn it into a string on
        // the stack and invoke the instance method System.out.println()
        // to print the string
        e.addMemberAccessInstruction(INVOKEVIRTUAL, "java/lang/StringBuffer",
                                                    "toString", 
                                                    "()Ljava/lang/String;");
        e.addMemberAccessInstruction(INVOKEVIRTUAL, "java/io/PrintStream",
                                                    "println", 
                                                    "(Ljava/lang/String;)V");
        e.addNoArgInstruction(RETURN);
        //this is for if n is a prime number
        e.addLabel("Label5");
        //else n is not a prime number
        //get system out on the stack
        e.addMemberAccessInstruction(GETSTATIC, "java/lang/System", "out",
                                                "Ljava/io/PrintStream;");
         // Create an intance sb of StringBuffer on the stack and duplicate it
        e.addReferenceInstruction(NEW, "java/lang/StringBuffer");
        e.addNoArgInstruction(DUP);
        // Invoke the constructor StringBuffer()
        e.addMemberAccessInstruction(INVOKESPECIAL, "java/lang/StringBuffer",
                                                    "<init>", 
                                                    "()V");
        // Load n on the stack and append it to sb
        e.addNoArgInstruction(ILOAD_1);
        e.addMemberAccessInstruction(INVOKEVIRTUAL, "java/lang/StringBuffer",
                                                    "append", 
                                                "(I)Ljava/lang/StringBuffer;");
        // Load the constant " is not a prime number" on the stack
        // and call instance
        // method StringBuffer.append() to append it to sb
        e.addLDCInstruction(" is a prime number");
        e.addMemberAccessInstruction(INVOKEVIRTUAL, "java/lang/StringBuffer",
                                                    "append", 
                                "(Ljava/lang/String;)Ljava/lang/StringBuffer;");
        // Invoke instance method sb.toString() to turn it into a string on
        // the stack and invoke the instance method System.out.println()
        // to print the string
        e.addMemberAccessInstruction(INVOKEVIRTUAL, "java/lang/StringBuffer",
                                                    "toString", 
                                                    "()Ljava/lang/String;");
        e.addMemberAccessInstruction(INVOKEVIRTUAL, "java/io/PrintStream",
                                                    "println", 
                                                    "(Ljava/lang/String;)V");

        // Return from the method
        e.addNoArgInstruction(RETURN);

        // Write IsPrime.class to file system
        
            
        e.write();
    }
}
